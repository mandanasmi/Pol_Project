$(document).ready(function(){
    
    //give fadeIn to introduction section in EmployeeAcountPage
    $("#introduction").fadeIn(3500);
    
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Prevent default anchor click behavior
  event.preventDefault();

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
});

$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
      
  });
    

    
    
});

/** POP UP **/

/** POP UP **/


/** Employee Acount page **/

$(function() { 
   $("#peg-pb-one").addClass("progress-bar-color");
   $("#peg-pb-two").addClass("progress-bar-color");
   $("#peg-pb-three").addClass("progress-bar-color");
   $("#peg-pb-four").addClass("progress-bar-color");
   $("#peg-pb-five").addClass("progress-bar-color");
    
    
    $("#peg-pb-one").animate({
        width: "50%"
    }, 2500);

    $("#peg-pb-two").animate({
        width: "40%"
    }, 2500);

    $("#peg-pb-three").animate({
        width: "70%"
    }, 2500);
    
    $("#peg-pb-four").animate({
        width: "60%"
    }, 2500);
    
    $("#peg-pb-five").animate({
        width: "20%"
    }, 2500);
    
    
    $("#peg-resume-dl-btn").addClass("peg-resume-dl");
    
    
});

	function registerFunction(){
		
		var checkedValue = document.querySelector('input[name=Rmembership]:checked').value;
		//var checkedValue =  $('.RegisterCheckbox input:radio:checked').val();
		if(CheckedValue = "employer")
			window.location="Account Setting/accountsetting_Employer.html";
		else 
			window.location="Account Setting/accountsetting_Employee.html";
	}
	function loginFunction(){
		
		var checkedValue = document.querySelector('input[name=Lmembership]:checked').value;
		if(CheckedValue = "employee")
			window.location="Account Setting/accountsetting_Employee.html";
		else 
			window.location="Account Setting/accountsetting_Employer.html";
	}
